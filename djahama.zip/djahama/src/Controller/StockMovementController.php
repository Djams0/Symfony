<?php

namespace App\Controller;

use App\Entity\StockMovement;
use App\Entity\Product;
use App\Form\StockMovementType;
use App\Repository\StockMovementRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class StockMovementController extends AbstractController
{
    #[Route('/stock/movement', name: 'app_stock_movement')]
    public function index(StockMovementRepository $repository): Response
    {
        $movements = $repository->findAll();
        return $this->render('stock_movement/index.html.twig', [
            'movements' => $movements,
        ]);
    }

    #[Route('/stock/movement/new', name: 'stock_movement_new')]
    public function new(Request $request, EntityManagerInterface $em): Response
    {
        $stockMovement = new StockMovement();
        $form = $this->createForm(StockMovementType::class, $stockMovement);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Récupérer les informations du mouvement
            $movementType = $stockMovement->getMovementType();
            $quantity = $stockMovement->getQuantity();
            $product = $stockMovement->getProduct();

            // Mettre à jour la quantité du produit en fonction du mouvement (ajout ou retrait)
            if ($movementType === 'in') {
                $product->setQuantity($product->getQuantity() + $quantity);
            } else {
                $product->setQuantity($product->getQuantity() - $quantity);
            }

            // Enregistrer le mouvement de stock
            $stockMovement->setDate(new \DateTime());
            $em->persist($stockMovement);
            $em->flush();

            // Enregistrer les modifications du produit
            $em->persist($product);
            $em->flush();

            $this->addFlash('success', 'Mouvement de stock enregistré avec succès !');
            return $this->redirectToRoute('app_stock_movement');
        }

        return $this->render('stock_movement/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}

