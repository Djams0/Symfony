<?php

// src/Controller/ProductController.php
namespace App\Controller;

use App\Entity\Category;
use App\Entity\Product;
use App\Form\ProductType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProductController extends AbstractController
{

    #[Route('/', name: 'product_list')]
    public function index(Request $request, EntityManagerInterface $em): Response
    {

        // if (!$authChecker->isGranted('ROLE_ADMIN')) {
        //     throw $this->createAccessDeniedException('Vous n\'avez pas les droits nécessaires');
        // }

        $categoryFilter = $request->query->get('category');
        $quantityFilter = $request->query->get('quantity', 0); // Par défaut, pas de filtre sur la quantité

        // Rechercher les catégories pour le filtre
        $categories = $em->getRepository(Category::class)->findAll();

        // Rechercher les produits avec des filtres appliqués
        $queryBuilder = $em->getRepository(Product::class)->createQueryBuilder('p');

        if ($categoryFilter) {
            $queryBuilder->andWhere('p.category = :category')
                         ->setParameter('category', $categoryFilter);
        }

        if ($quantityFilter) {
            $queryBuilder->andWhere('p.quantity < :quantity')
                         ->setParameter('quantity', 5);
        }

        $products = $queryBuilder->getQuery()->getResult();

        // Vérifier le stock de chaque produit et afficher une alerte si la quantité est basse
        foreach ($products as $product) {
            if ($product->getQuantity() < 5) {
                $this->addFlash('warning', "Le stock du produit \"{$product->getName()}\" est bas !");
            }
        }

        return $this->render('product/index.html.twig', [
            'products' => $products,
            'categories' => $categories,
            'categoryFilter' => $categoryFilter,
            'quantityFilter' => $quantityFilter,
        ]);
    }

    /**
     * @Route("/product/new", name="product_new")
     */
    #[Route('/product/new', name: 'product_new')]
    public function new(Request $request, EntityManagerInterface $em): Response
    {
        $product = new Product();
        $form = $this->createForm(ProductType::class, $product);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Récupérer la valeur de la nouvelle catégorie
            $newCategoryName = $form->get('newCategory')->getData();

            if ($newCategoryName) {
                // Rechercher si la catégorie existe déjà
                $existingCategory = $em->getRepository(Category::class)->findOneBy(['name' => $newCategoryName]);

                if (!$existingCategory) {
                    $category = new Category();
                    $category->setName($newCategoryName);
                    $em->persist($category);
                    $product->setCategory($category);
                } else {
                    $product->setCategory($existingCategory);
                }
            }

            $em->persist($product);
            $em->flush();

            $this->addFlash('success', 'Produit ajouté avec succès !');
            return $this->redirectToRoute('product_list');
        }

        return $this->render('product/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }


    /**
     * @Route("/product/{id}/edit", name="product_edit")
     */
    #[Route('/product/{id}/edit', name: 'product_edit')]
    public function edit(Request $request, Product $product, EntityManagerInterface $em): Response
    {
        $form = $this->createForm(ProductType::class, $product);
        $form->handleRequest($request);
    
        if ($form->isSubmitted() && $form->isValid()) {
            // Vérification du stock
            if ($product->getQuantity() < 5) {
                $this->addFlash('warning', 'Le stock de ce produit est bas !');
            }
    
            $em->flush();
            return $this->redirectToRoute('product_list');
        }
    
        return $this->render('product/edit.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /**
    * @Route("/product/{id}/delete", name="product_delete")
    */
    #[Route('/product/{id}/delete', name: 'product_delete')]
    public function delete(Request $request, Product $product, EntityManagerInterface $em): Response
    {
        // Vérifier que le produit existe
        if (!$product) {
            $this->addFlash('error', 'Le produit n\'existe pas.');
            return $this->redirectToRoute('product_list');
        }

        // Suppression du produit
        $em->remove($product);
        $em->flush();

        $this->addFlash('success', 'Produit supprimé avec succès !');
        return $this->redirectToRoute('product_list');
    }

    
}
