<?php
// src/Form/ProductType.php

namespace App\Form;

use App\Entity\Product;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\NumberType; // Importez NumberType
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use App\Entity\Category;
use Symfony\Component\Validator\Constraints as Assert;

class ProductType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('name')
            ->add('price')
            ->add('description')
            ->add('quantity', NumberType::class, [
                'required' => true, // ou false selon le cas
                'label' => 'Quantité',
                'attr' => ['min' => 0], // Optionnel : pour définir un minimum
            ])
            ->add('category', EntityType::class, [
                'class' => Category::class,
                'choice_label' => 'name',
                'placeholder' => 'Choisissez une catégorie',
                'required' => false,
            ])
            ->add('newCategory', TextType::class, [
                'mapped' => false, // Ce champ n'est pas relié à l'entité Product
                'required' => false,
                'label' => 'Ou ajoutez une nouvelle catégorie',
                'attr' => ['placeholder' => 'Entrez le nom de la nouvelle catégorie ici']
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Product::class,
        ]);
    }
}
