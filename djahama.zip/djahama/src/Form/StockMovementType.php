<?php

namespace App\Form;

use App\Entity\Product;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class StockMovementType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('product', EntityType::class, [
                'class' => Product::class,
                'choice_label' => 'name',
                'label' => 'Produit',
            ])
            ->add('movement_type', ChoiceType::class, [
                'choices' => [
                    'Entrée' => 'in',
                    'Sortie' => 'out',
                ],
                'label' => 'Type de mouvement',
            ])
            ->add('quantity', NumberType::class, [
                'label' => 'Quantité',
            ])
            ->add('reason', TextareaType::class, [
                'label' => 'Raison',
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            // Aucune entité associée ici, le formulaire n'est pas lié à une entité
        ]);
    }
}
